/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents;

public enum PROPOSER_STATUS {

	NONE,
	
	PREPARE,
	
	ACCEPT,
//	ACCEPTED,
	PROMISE,
	
	DECIDED,
	
	PROPOSE,
	PROPOSAL_SUBSUMED,
}
