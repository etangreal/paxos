/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents;

import java.util.UUID;

import conf.*;
import communication.*;

public class Proposer
{	final static String CLASS = "Proposer";

	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS
	//-------------------------------------------------------------------------------------------------------

	private UUID _uid = UUID.randomUUID();
	int _id = 0;

	MulticastSender _acceptors;
	MulticastChannel _proposers;

	int _proposalNumber = 0;
	int _proposalValue = 0;
	
	int _acceptedPrepareCount = 0;
	int _seenAcceptedProposalNumber = -1;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public Proposer(Config config, int id, int proposalNumber, int proposalValue)
	{	
		_id = id;
		_acceptors = new MulticastSender(id, config.getAcceptorsIp(), config.getAcceptorsPort() );
		_proposers = new MulticastChannel(id, config.getProposersIP(), config.getProposersPort() );
	}
	
	private void run()
	{
		
	}

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------
	
	//foreach acceptor in acceptorList -> messageSend -> SendMessage
	//acceptor, Accept, proposalNumber, proposalValue -> Message
	private void SendMessage(Message message)
	{
		message.getAgentInfo().setInfo(_uid, _id, AGENT_TYPE.PROPOSER);
		_acceptors.DispatchMessage(message);
	}
	
	//messageReceived(ProposalAccepted, acceptedProposalNumber, acceptedValue)
	//[acceptedPrepareCount < quorumSize(acceptorList.count)]
	public void OnMessageReceived(Message message)
	{

	}
	
	private int GenerateNextProposalNumber()
	{
		return 0;
	}
	
	public void Propose()
	{
	
	}
	
	private void Heartbeat()
	{
		
	}
	
	//-------------------------------------------------------------------------------------------------------
	//EVENTS
	//-------------------------------------------------------------------------------------------------------

	private void OnStartProposing()
	{
	}
	
	private void OnAccepted()
	{
	}
	
	private void OnProposalSubsumed()
	{
	}

	private void OnPromise()
	{	
	}
	
	//public override bool ProcessTimeouts()
	
	//-------------------------------------------------------------------------------------------------------	
	
}//public class Proposer 
