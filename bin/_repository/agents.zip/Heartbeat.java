package agents;

import java.util.Timer;

//Example: www.gammelsaeter.com/programming/simple-timer-example-in-java/

public class Heartbeat 
{
	final static long HEARTBEAT = 2*1000;				// 2 seconds
	final static long HEARTBEAT_TIMEOUT = 3*1000;		// 3 secons
	
	Timer _tHeartbeat = null;
	
	public Heartbeat()
	{
		_tHeartbeat = new Timer();
	}
	
}
