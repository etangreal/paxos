/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents;

import communication.*;

public class Agent 
{
	MulticastSender sender;
	
	public Agent(String id, String ipaddress, int port)
	{
		
	}

}//public class Agent 
