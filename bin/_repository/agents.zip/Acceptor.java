package agents;

public class Acceptor {

}
