
/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents.proposer;

public class P1_Ready_with_value implements ProposerState
{
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS
	//-------------------------------------------------------------------------------------------------------
	
	Proposer _proposer;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public P1_Ready_with_value(Proposer proposer) {
		this._proposer = proposer;
	};

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------

	public String toString() {

		String status = "P1_Ready_with_value::toString()";
		
		return status;
	}
	
	public PROPOSER_STATE STATE() { return PROPOSER_STATE.P1_READY_WITH_VALUE; } 
	
	//-------------------------------------------------------------------------------------------------------
	//States

	//state: empty
		//--progress
	public void D0(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->D0");
	}
	public void S(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->S");
	}
	
	//state: p1_pending
	public void TO1(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->TO1");
	}
	public void P(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->P");
	}
		//--progress
	public void D01(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->D01");
	}
	public void R0(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->R0");
	}
	public void R1(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->R1");
	}
	
	//state: p1_ready_without_value
	public void NV(){
		System.out.println("              EXECUTED | P1_Ready_with_value->NV");
	}
		//--progress
	public void D2(){
		System.out.println("              EXECUTED | P1_Ready_with_value->D2");
	}
	public void A(){
		System.out.println("              EXECUTED | P1_Ready_with_value->A");
	}

	//state: p1_ready_with_value
		//--progress
	public void D3(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->D3");
	}
	public void E(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->E");
	}

	//state: p2_pending
	public void TO2(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->TO2");
	}
		//--progress
	public void D4(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->D4");
	}
	public void C(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->C");
	}

	//state: closed
		//--progress
	public void D5(){
		System.out.println("          NOT-EXECUTED | P1_Ready_with_value->D5");
	}

	//state: delivered

	//-------------------------------------------------------------------------------------------------------

}//P1_Ready_with_value
