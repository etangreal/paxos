
/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents.proposer;

public class Delivered implements ProposerState
{
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS
	//-------------------------------------------------------------------------------------------------------

	Proposer _proposer;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public Delivered(Proposer proposer) {
		this._proposer = proposer;
	};

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------

	public String toString() {

		String status = "Delivered::toString()";

		return status;
	}
	
	public PROPOSER_STATE STATE() { return PROPOSER_STATE.DELIVERED; } 

	//-------------------------------------------------------------------------------------------------------
	//States
	
	//state: empty
		//--progress
	public void D0(){
		System.out.println("Delivered->D0");
	}
	public void S(){
		System.out.println("Delivered->S");
	}

	//state: p1_pending
	public void TO1(){
		System.out.println("Delivered->TO1");
	}
	public void P(){
		System.out.println("Delivered->P");
	}
		//--progress
	public void D01(){
		System.out.println("Delivered->D01");
	}
	public void R0(){
		System.out.println("Delivered->R0");
	}
	public void R1(){
		System.out.println("Delivered->R1");
	}

	//state: p1_ready_without_value
	public void NV(){
		System.out.println("Delivered->NV");
	}
		//--progress
	public void D2(){
		System.out.println("Delivered->D2");
	}
	public void A(){
		System.out.println("Delivered->A");
	}

	//state: p1_ready_with_value
		//--progress
	public void D3(){
		System.out.println("Delivered->D3");
	}
	public void E(){
		System.out.println("Delivered->E");
	}

	//state: p2_pending
	public void TO2(){
		System.out.println("Delivered->TO2");
	}
		//--progress
	public void D4(){
		System.out.println("Delivered->D4");
	}
	public void C(){
		System.out.println("Delivered->C");
	}

	//state: closed
		//--progress
	public void D5(){
		System.out.println("Delivered->D5");
	}

	//state: delivered

	//-------------------------------------------------------------------------------------------------------

}//Delivered
