
/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents.proposer;

import communication.*;
import conf.Config;
import interfaces.Callable;

import java.util.Timer;
import java.util.UUID;
import javax.swing.SwingUtilities;

public class Proposer implements Callable
{
	public final static int MILLISECONDS = 1000;
	
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS (by convention all global class members are prefixed with an underscore "_")
	//-------------------------------------------------------------------------------------------------------

	//Proposer: AgentInfo Contains { uid, id, AGENT_TYPE } 
	AgentInfo _agentInfo = null;
	
	//Communication
	MulticastChannel _acceptors;
	MulticastChannel _proposers;

	
	//Configuration
	int _numberOfAcceptors = 0;
	
	//	heartbeat
	long _heartbeatInterval = 3*MILLISECONDS; // {x}*milliseconds
	Timer _heatbeat = null;
	

	//_pending_list			//when the client sends values to the proposer(leader) it is stored in this pending list

	//States
	Empty _empty;
	P1_Pending _p1_pending;
	P1_Ready_without_value _p1_ready_without_value;
	P1_Ready_with_value _p1_ready_with_value;
	P2_Pending _p2_pending;
	P2_Closed _p2_closed;
	Delivered _delivered;

	//    State info: <i,S,b,pset,v1,vb,v2,false>
	//Initialized to: <0,empty,0,{0},null,0,null,false>
	int _i; 				//i: is the instance number - each instance should be a unique one; we should use uuid?
	//S						//S: is a symbol representing the state
	ProposerState _state;
	int _b;					//b: is a ballot
	int _pset[]; 			//pset: is a set of promises received
	int _v1;				//v1: is the value found after a successful phase 1
	int _vb; 				//vb: is the corresponding ballot
	int _v2;				//v2: is the value to use for phase 2
	int _cv;				//cv: is a flag to indicate weather v2 is a value received from the client

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public Proposer(Config config, int id, int proposalNumber, int proposalValue)
	{
		//Proposer
		_agentInfo = new AgentInfo(UUID.randomUUID(), id, AGENT_TYPE.PROPOSER);

		 _numberOfAcceptors = config.getNumberOfAcceptors();
		 _heartbeatInterval = config.getHeartbeatInterval()*MILLISECONDS;
		 
		//Initialize States
		_empty = new Empty(this);
		_p1_pending = new P1_Pending(this);
		_p1_ready_without_value = new P1_Ready_without_value(this);
		_p1_ready_with_value = new P1_Ready_with_value(this);
		_p2_pending = new P2_Pending(this);
		_p2_closed = new P2_Closed(this);
		_delivered = new Delivered(this);

		//State Info:
		//Initialized to: <0,empty,0,{0},null,0,null,false>
		_i = 0;
		_state = _empty;							//S = empty;
		_b = 0;
		_pset = new int[_numberOfAcceptors]; 		//EMPTY SET
		_v1 = 0;
		_vb = 0;
		_v2 = 0;
		_cv = 0;

		//Initialize Communication Objects
		_acceptors = new MulticastChannel(  id, config.getAcceptorsIp(), config.getAcceptorsPort() );
		_proposers = new MulticastChannel( id, config.getProposersIP(), config.getProposersPort() );

		//Heartbeat
		_heatbeat = new Timer();
		_heatbeat.schedule(
			new HeartbeatTask(1, this), 	// Task Object, implements the Runnable interface
			0, 								// Initial delay
			_heartbeatInterval				// Subsequent Interval
		);
		
		run();
	}

	private void run()
	{
		while(true)
		{
			//ToDo:
		}
		
	}//run
	
	//-------------------------------------------------------------------------------------------------------
	//EVENTS | CALLBACKS
	//-------------------------------------------------------------------------------------------------------

	//from interface Callable
	public void callback(final String method, final String[] args)
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {

				String argAsString = "";
				for(int i=0; i < args.length; i ++ )
					argAsString = argAsString + " " + args[i];

				switch ( method.toLowerCase() ) 
				{
					case "onheartbeat":
						OnHeartbeat(args);
						break;
					default:
						System.out.println("Proposer::callback::default");
						System.out.println("Method '" + method + "' could not be found ...");
						System.out.println("Arguments: " + argAsString);
						break;
				}

			}//run
		});//invokeLater
	}//callback

	public void OnHeartbeat( final String[] args )
	{
		String argAsString = "";
		for(int i=0; i < args.length; i ++ )
			argAsString = argAsString + " " + args[i];
		argAsString = argAsString.trim();

		System.out.println("Proposer::OnHeartbeat");
		System.out.println("Arguments: " + argAsString);
		
		Message msg = new Message(MESSAGE_TYPE.HEARTBEAT, AGENT_TYPE.PROPOSER, _agentInfo);
		_proposers.DispatchMessage(msg);
	}

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------
	
	//foreach acceptor in acceptorList -> messageSend -> SendMessage
	//acceptor, Accept, proposalNumber, proposalValue -> Message
	private void SendMessage(Message message)
	{
		message.getAgentInfo().Copy(_agentInfo);
		_acceptors.DispatchMessage(message);
	}
	
	void setState(ProposerState state) {
		this._state = state;
	}

	public String toString() 
	{
		String status = "Proposer::toString() | " + _state;

		return status;
	}
	
	public void displayState()
	{
		System.out.println("\n----------------------Empty State----------------------");
		System.out.println(this);
		//state: empty
			//--progress
		this.D0();
		this.S();

		System.out.println("\n----------------------p1_pending State----------------------");
		System.out.println(this);
		//state: p1_pending
		this.TO1();
		this.P();
			//--progress
		this.D01();
		this.R0();
		this.R1();

		System.out.println("\n----------------------p1_ready_without_value State----------------------");
		System.out.println(this);
		//state: p1_ready_without_value
		this.NV();
			//--progress
		this.D2();
		this.A();

		System.out.println("\n----------------------p1_ready_with_value State----------------------");
		System.out.println(this);
		//state: p1_ready_with_value
			//--progress
		this.D3();
		this.E();

		System.out.println("\n----------------------p2_pending State----------------------");
		System.out.println(this);
		//state: p2_pending
		this.TO2();
			//--progress
		this.D4();
		this.C();

		System.out.println("\n----------------------closed State----------------------");
		System.out.println(this);
		//state: closed
			//--progress
		this.D5();

		System.out.println("\n----------------------delivered State----------------------");
		System.out.println(this);
		//state: delivered
		
	}//displayState

	//-------------------------------------------------------------------------------------------------------
	//STATE TRANSITIONS
	//-------------------------------------------------------------------------------------------------------
	
	//state: empty
		//--progress
	public void D0(){
		System.out.println("Proposer->D0");
		_state.D0();
	}
	public void S(){
		System.out.println("Proposer->S");
		_state.S();
	}

	//state: p1_pending
	public void TO1(){
		System.out.println("Proposer->TO1");
		_state.TO1();
	}
	public void P(){
		System.out.println("Proposer->P");
		_state.P();
	}
		//--progress
	public void D01(){
		System.out.println("Proposer->D01");
		_state.D01();
	}
	public void R0(){
		System.out.println("Proposer->R0");
		_state.R0();
	}
	public void R1(){
		System.out.println("Proposer->R1");
		_state.R1();
	}

	//state: p1_ready_without_value
	public void NV(){
		System.out.println("Proposer->NV");
		_state.NV();
	}
		//--progress
	public void D2(){
		System.out.println("Proposer->D2");
		_state.D2();
	}
	public void A(){
		System.out.println("Proposer->A");
		_state.A();
	}

	//state: p1_ready_with_value
		//--progress
	public void D3(){
		System.out.println("Proposer->D3");
		_state.D3();
	}
	public void E(){
		System.out.println("Proposer->E");
		_state.E();
	}

	//state: p2_pending
	public void TO2(){
		System.out.println("Proposer->TO2");
		_state.TO2();
	}
		//--progress
	public void D4(){
		System.out.println("Proposer->D4");
		_state.D4();
	}
	public void C(){
		System.out.println("Proposer->C");
		_state.C();
	}

	//state: closed
		//--progress
	public void D5(){
		System.out.println("Proposer->D5");
		_state.D5();
	}

	//state: delivered

	//-------------------------------------------------------------------------------------------------------
	
}//Proposer
