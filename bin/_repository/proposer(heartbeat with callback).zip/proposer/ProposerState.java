
/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents.proposer;

public interface ProposerState 
{	
	//-------------------------------------------------------------------------------------------------------

	public String toString();

	public PROPOSER_STATE STATE();

	//-------------------------------------------------------------------------------------------------------	

	//state: empty
		//--progress
	public void D0();
	public void S();

	//state: p1_pending
	public void TO1();
	public void P();
		//--progress
	public void D01();
	public void R0();
	public void R1();
	
	//state: p1_ready_without_value
	public void NV();
		//--progress
	public void D2();
	public void A();
	
	//state: p1_ready_with_value
		//--progress
	public void D3();
	public void E();
	
	//state: p2_pending
	public void TO2();
		//--progress
	public void D4();
	public void C();
	
	//state: closed
		//--progress
	public void D5();
	
	//state: delivered
	
	//-------------------------------------------------------------------------------------------------------
	
}//State
