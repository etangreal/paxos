
/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents.proposer;

public class Empty implements ProposerState 
{	
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS
	//-------------------------------------------------------------------------------------------------------

	Proposer _proposer;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public Empty(Proposer proposer) {
		this._proposer = proposer;
	};

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------

	public String toString() 
	{
		String status = "Empty::toString()";

		return status;
	}

	public PROPOSER_STATE STATE() { return PROPOSER_STATE.EMPTY; } 

	//-------------------------------------------------------------------------------------------------------
	//States

	//state: empty
		//--progress
	public void D0(){
		System.out.println("              EXECUTED | Empty->D0");
	}
	public void S(){
		System.out.println("              EXECUTED | Empty->S");
	}

	//state: p1_pending
	public void TO1(){
		System.out.println("          NOT-EXECUTED | Empty->TO1");
	}
	public void P(){
		System.out.println("          NOT-EXECUTED | Empty->P");
	}
		//--progress
	public void D01(){
		System.out.println("          NOT-EXECUTED | Empty->D01");
	}
	public void R0(){
		System.out.println("          NOT-EXECUTED | Empty->R0");
	}
	public void R1(){
		System.out.println("          NOT-EXECUTED | Empty->R1");
	}
	
	//state: p1_ready_without_value
	public void NV(){
		System.out.println("          NOT-EXECUTED | Empty->NV");
	}
		//--progress
	public void D2(){
		System.out.println("          NOT-EXECUTED | Empty->D2");
	}
	public void A(){
		System.out.println("          NOT-EXECUTED | Empty->A");
	}
	
	//state: p1_ready_with_value
		//--progress
	public void D3(){
		System.out.println("          NOT-EXECUTED | Empty->D3");
	}
	public void E(){
		System.out.println("          NOT-EXECUTED | Empty->E");
	}
	
	//state: p2_pending
	public void TO2(){
		System.out.println("          NOT-EXECUTED | Empty->TO2");
	}
		//--progress
	public void D4(){
		System.out.println("          NOT-EXECUTED | Empty->D4");
	}
	public void C(){
		System.out.println("          NOT-EXECUTED | Empty->C");
	}
	
	//state: closed
		//--progress
	public void D5(){
		System.out.println("          NOT-EXECUTED | Empty->D5");
	}

	//state: delivered

	//-------------------------------------------------------------------------------------------------------

}//Empty
