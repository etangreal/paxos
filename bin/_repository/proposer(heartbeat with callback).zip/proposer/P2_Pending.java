
/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package agents.proposer;

public class P2_Pending implements ProposerState
{
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS
	//-------------------------------------------------------------------------------------------------------
	
	Proposer _proposer;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public P2_Pending(Proposer proposer) {
		this._proposer = proposer;
	};

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------

	public String toString() {

		String status = "P2_Pending::toString()";
		
		return status;
	}
	
	public PROPOSER_STATE STATE() { return PROPOSER_STATE.P2_PENDING; } 
	
	//-------------------------------------------------------------------------------------------------------
	//States
	
	//state: empty
		//--progress
	public void D0(){
		System.out.println("          NOT-EXECUTED | P2_Pending->D0");
	}
	public void S(){
		System.out.println("          NOT-EXECUTED | P2_Pending->S");
	}
	
	//state: p1_pending
	public void TO1(){
		System.out.println("          NOT-EXECUTED | P2_Pending->TO1");
	}
	public void P(){
		System.out.println("          NOT-EXECUTED | P2_Pending->P");
	}
		//--progress
	public void D01(){
		System.out.println("          NOT-EXECUTED | P2_Pending->D01");
	}
	public void R0(){
		System.out.println("          NOT-EXECUTED | P2_Pending->R0");
	}
	public void R1(){
		System.out.println("          NOT-EXECUTED | P2_Pending->R1");
	}
	
	//state: p1_ready_without_value
	public void NV(){
		System.out.println("          NOT-EXECUTED | P2_Pending->NV");
	}
		//--progress
	public void D2(){
		System.out.println("          NOT-EXECUTED | P2_Pending->D2");
	}
	public void A(){
		System.out.println("          NOT-EXECUTED | P2_Pending->A");
	}
	
	//state: p1_ready_with_value
		//--progress
	public void D3(){
		System.out.println("          NOT-EXECUTED | P2_Pending->D3");
	}
	public void E(){
		System.out.println("          NOT-EXECUTED | P2_Pending->E");
	}
	
	//state: p2_pending
	public void TO2(){
		System.out.println("              EXECUTED | P2_Pending->TO2");
	}
		//--progress
	public void D4(){
		System.out.println("              EXECUTED | P2_Pending->D4");
	}
	public void C(){
		System.out.println("              EXECUTED | P2_Pending->C");
	}

	//state: closed
		//--progress
	public void D5(){
		System.out.println("          NOT-EXECUTED | P2_Pending->D5");
	}

	//state: delivered

	//-------------------------------------------------------------------------------------------------------
	
}//P2_Pending
