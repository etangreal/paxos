package TCPCommunication;

import java.io.*;
import java.net.*;

public class TCPClientWorker implements Runnable
{
	Socket clientSocket = null;
	String id = "<none>";

    //-------------------------------------------------------------------------------------------------------

	public TCPClientWorker(Socket client, String id)
	{
		this.clientSocket = client;
		this.id = id;
	}

	//-------------------------------------------------------------------------------------------------------

	@Override
	public void run() {

	    BufferedReader in = null;
	    PrintWriter out = null;

	    String inputLine, outputLine;

	    inputLine = "<no-input>\n";
	    outputLine = "<connection-initialized>\n";

	    //-------------------------------------------------------------------------------------------------------

	   //Get socket input and output streams
		try {
	        out = new PrintWriter( clientSocket.getOutputStream(), true );
	        in =  new BufferedReader( new InputStreamReader( clientSocket.getInputStream() ));
		}
		catch (IOException e) {
			System.out.println("TCPClientWorker::Error on BufferedReader/Writer::message::" + e.getMessage() );
			e.printStackTrace();
		}

		outputLine = "TCPServer-worker("+id+"):Connection-Initialized.";
		System.out.println(outputLine);
        out.println(outputLine);

        try {
			while (	(inputLine = in.readLine()	) != null ) {
				outputLine = "TCPServer-worker("+id+") received:"+inputLine;
				System.out.println(outputLine);
				
			    if (inputLine.toLowerCase().equals("bye.")) {
			    	System.out.println("Client said bye. Exiting ...");
			    	out.println(inputLine);
			    	break;
			    }

			    out.println(outputLine);
			}
		} catch (IOException e) {
			System.out.println("TCPClientWorker::Error on readLine::message::" + e.getMessage() );
			e.printStackTrace();
		}

        try {
            out.close();
			in.close();
	        clientSocket.close();
		} catch (IOException e) {
			System.out.println("TCPClientWorker::Error on Closing Stream & Sockets::message::" + e.getMessage() );
			e.printStackTrace();
		}

	}//public void run

	//-------------------------------------------------------------------------------------------------------

}//public class TCPClientWorker
	


