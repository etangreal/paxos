package TCPCommunication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class MulticastTest {

	MulticastSocket socket = null;
	String address = "239.0.0.1";
	int port = 3000;
	InetAddress group = null;

	//-------------------------------------------------------------------------------------------------------

	public MulticastTest(String address, int port)
	{
		this.address = address;
		this.port = port;

		try {
			group = InetAddress.getByName(address);
			socket = new MulticastSocket(port);
			socket.joinGroup(group);
		} catch (IOException e) {
			System.out.println( "MulticastTest::MulticastTest()::" + e.getMessage() );
			e.printStackTrace();
		}

		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		String message = "<no-message>";

		while(true)
		{
			try {
				System.out.println("Enter msg:");
				message = stdIn.readLine();
			} catch (IOException e) {
				System.out.println( "MulticastTest::MulticastTest()::while::stdIn.readLine()::" + e.getMessage() );
				e.printStackTrace();
			}
			
			SendMessage(message);
			
            if(message.toLowerCase().equals("bye."))
            {
            	System.out.println("Exiting...");
            	System.exit(0);
            }
		}

	}//public MulticastTest()
	
	//-------------------------------------------------------------------------------------------------------
	
	public void SendMessage(String message)
	{
		DatagramPacket packet = new DatagramPacket(message.getBytes(), message.length(), group, port);

		try {
			socket.send(packet);
		} catch (IOException e) {
			System.out.println( "::MulticastTest::SendMessage(String message)::socket.send(packet)::\n\t" + e.getMessage() );
			e.printStackTrace();
		}
	}
	
	//-------------------------------------------------------------------------------------------------------
	
}//public class TCPMultiCastServer
