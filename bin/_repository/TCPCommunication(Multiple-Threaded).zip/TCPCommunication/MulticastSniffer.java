package TCPCommunication;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;

public class MulticastSniffer //implements Runnable 
{

	MulticastSocket socket = null;
	String id = "0";
	String address = "239.0.0.1";
	int port = 3000;
	InetAddress group = null;

	//-------------------------------------------------------------------------------------------------------

	public MulticastSniffer(String id, String address, int port)
	{
		this.id = id;
		this.port = port;
		this.address = address;
		run();
	}

	//-------------------------------------------------------------------------------------------------------

	//@Override
	public void run() {

		try {
			group = InetAddress.getByName(address);
			socket = new MulticastSocket(port);
			socket.joinGroup(group);
		} catch (IOException e) {
			System.out.println( "MulticastSniffer::run()::" + e.getMessage() );
			e.printStackTrace();
		}
		
		byte[] buffer = new byte[65535];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        
		while(true)
		{
			String message = "<no-message>";
			
			try {
				socket.receive(packet);
	            message = new String(packet.getData(),0,packet.getLength());
	            System.out.println(message);
			}
	        catch (SocketException e) {
	        	System.out.println( "MulticastSniffer::run()::SocketException::" + e.getMessage() );
	            System.err.println(e);
	        }
			catch (IOException e) {
				System.out.println( "MulticastSniffer::run()::IOException::" + e.getMessage() );
				e.printStackTrace();
			}

            if(message.toLowerCase().equals("bye."))
            {
            	System.out.println("Exiting...");
            	System.exit(0);
            }
		}

	}//public void run()

	//-------------------------------------------------------------------------------------------------------

}//public class MulticastSniffer 
