package TCPCommunication;

import java.net.*;
import java.io.*;

public class TCPServer 
{
	public TCPServer()
	{
		int counter = 0;
        ServerSocket serverSocket = null;

        try {
            serverSocket = new ServerSocket(4444);
        }
        catch (IOException e) 
        {
            System.err.println("Could not listen on port: 4444.");
            System.exit(1);
        }

		while(true) {
			TCPClientWorker w;
			try {
				//server.accept returns a client connection
				w = new TCPClientWorker( serverSocket.accept(), Integer.toString(counter++) );
				Thread t = new Thread(w);
				t.start();
			} catch (IOException e) {
				System.out.println("Accept failed: 4444");
				System.exit(-1);
			}
		}

/*        
		try {
	        serverSocket.close();
		} catch (IOException e) {
			System.out.println("KnockKnowkServer::Error on Closing Stream & Sockets::message::" + e.getMessage() );
			e.printStackTrace();
		}
*/

	}//public TCPServer()

}//public class TCPServer
