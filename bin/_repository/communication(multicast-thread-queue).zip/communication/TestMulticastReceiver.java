/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package communication;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

//import java.util.concurrent.BlockingQueue;

public class TestMulticastReceiver 
{
	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public TestMulticastReceiver()
	{
		System.out.println("Starting Client...\n");
		MulticastReceiver r = new MulticastReceiver("1", "239.0.0.1", 3000);		
		Thread t = new Thread(r);
		t.start();

		while(true)
		{
			try {
				System.out.println("\n--------------------------------------------------------------------------------");
				System.out.println("Reading from queue...");
				
				Message msg = r.getQueue().take();
				
				System.out.println( "\nTestMulticastReceiver::Received Message: "+msg.getMessage() );
			} catch (InterruptedException e) {
				System.out.println( "TestMulticastReceiver::TestMulticastReceiver()::queue.take()::\n\t" + e.getMessage() );
				e.printStackTrace();
			}
		}

	}//public TestMulticastReceiver

	//-------------------------------------------------------------------------------------------------------
	
}//public class TestMulticastReceiver
