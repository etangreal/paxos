/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package communication;


public class Message 
{
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS

	public String _message;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	
	public Message() 
	{
		_message = "";
	}
	
	//-------------------------------------------------------------------------------------------------------
	//PROPERTIES
	
	public void setMessage(String message) {
		_message = message;
	}
	
	public String getMessage() {
		return _message;
	}
	
	public byte[] getBytes()
	{
		return _message.getBytes();
	}
	
	public int length()
	{
		return _message.length();
	}
	
	//-------------------------------------------------------------------------------------------------------
	//METHODS
	
	//-------------------------------------------------------------------------------------------------------
}
