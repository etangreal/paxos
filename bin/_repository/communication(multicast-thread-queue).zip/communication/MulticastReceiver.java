
/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package communication;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MulticastReceiver implements Runnable
{
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS
	//-------------------------------------------------------------------------------------------------------

	MulticastSocket _socket = null;
	String _id = "*";
	String _ipaddress = "239.0.0.1";
	int _port = 3000;
	InetAddress _group = null;
	BlockingQueue<Message> _queue;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public MulticastReceiver(String id, String ipaddress, int port)
	{
		this._id = id;
		this._port = port;
		this._ipaddress = ipaddress;
		_queue = new LinkedBlockingQueue<Message>();

		try {
			_group = InetAddress.getByName(_ipaddress);
			_socket = new MulticastSocket(_port);
			_socket.joinGroup(_group);
		}catch (UnknownHostException e) {
			System.out.println( "MulticastReceiver::MulticastReceiver()::_group = InetAddress.getByName(_ipaddress)" + e.getMessage() );
			e.printStackTrace();
		} catch (IOException e) {
			final String OFFENDING_CODE = " _socket = new MulticastSocket(_port) | _socket.joinGroup(_group) ";
			System.out.println( "MulticastReceiver::MulticastReceiver()::"+OFFENDING_CODE+"\n\t"+ e.getMessage() );
			e.printStackTrace();
		}
	}
	
	//-------------------------------------------------------------------------------------------------------
	
	@Override
	public void run() 
	{
		System.out.println("Multicast Receiver Started...");

		byte[] buffer = new byte[65535];
	    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

		while(true)
		{
			Message message = new Message();
			message.setMessage("<no-message>");

			try {
				_socket.receive(packet);
				message.setMessage( new String(packet.getData(),0,packet.getLength()) );

	            System.out.println("\nMulticastReceiver::Received message: " + message.getMessage() + "\n\t ... enqueuing message ...");
	            _queue.put(message);
			}
	        catch (SocketException e) {
	        	System.out.println( "MulticastReceiver::run()::SocketException::" + e.getMessage() );
	            System.err.println(e);
	        }
			catch (IOException e) {
				System.out.println( "MulticastReceiver::run()::IOException::" + e.getMessage() );
				e.printStackTrace();
			} catch (InterruptedException e) {
				System.out.println( "MulticastReceiver::run()::InterruptedException::" + e.getMessage() );
				e.printStackTrace();
			}

		}//while(true)

	}//public void run

	//-------------------------------------------------------------------------------------------------------
	//PROPERTIES
	//-------------------------------------------------------------------------------------------------------

	public BlockingQueue<Message> getQueue()
	{
		return _queue;
	}

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------	

	//add methods here ... 
	
	//-------------------------------------------------------------------------------------------------------	

}//public class MulticastReceiver
