/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package communication;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class MulticastSender implements Runnable
{
	//-------------------------------------------------------------------------------------------------------
	//DATA-MEMBERS
	//-------------------------------------------------------------------------------------------------------

	MulticastSocket _socket = null;
	String _id = "*";
	String _ipaddress = "239.0.0.1";
	int _port = 3000;
	InetAddress _group = null;
	BlockingQueue<Message> _queue;

	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public MulticastSender(String id, String ipaddress, int port)
	{
		this._id = id;
		this._ipaddress = ipaddress;
		this._port = port;
		_queue = new LinkedBlockingQueue<Message>();

		try {
			_group = InetAddress.getByName(_ipaddress);
			_socket = new MulticastSocket(_port);
			_socket.joinGroup(_group);
		} catch (IOException e) {
			System.out.println( "MulticastSender::MulticastSender()::" + e.getMessage() );
			e.printStackTrace();
		}

	}//public MulticastSender()

	//-------------------------------------------------------------------------------------------------------

	@Override
	public void run() 
	{
		System.out.println("MulticastServer Started...");

		processQueue();

	}//public void run

	//-------------------------------------------------------------------------------------------------------
	//METHODS
	//-------------------------------------------------------------------------------------------------------

	private void processQueue()
	{
		while(true)
		{
			Message msg = _queue.poll();
			SendMessage(msg);
		}
	}
	
	//-------------------------------------------------------------------------------------------------------

	public void EnqueueMessage(Message message)
	{
		try {
			_queue.put(message);
		} catch (InterruptedException e) {
			System.out.println( "EnqueueMessage::run()::InterruptedException::" + e.getMessage() );
			e.printStackTrace();
		}
	}

	//-------------------------------------------------------------------------------------------------------

	private boolean SendMessage(Message message)
	{
		DatagramPacket packet = new DatagramPacket( message.getBytes(), message.length(), _group, _port );

		try {
			_socket.send(packet);
			return true;
		} catch (IOException e) {
			System.out.println( "MulticastSender::SendMessage(String message)::socket.send(packet)::\n\t" + e.getMessage() );
			e.printStackTrace();
			//TODO: requeue message?
			return false;
		}
	}

	//-------------------------------------------------------------------------------------------------------
	
}//public class MulticastSender

