/*
 * Author: Ernst Salzmann
 * Date: 19-05-2012
 *
 */

package communication;

public class TestMulticastReceiver 
{
	//-------------------------------------------------------------------------------------------------------
	//CONSTRUCTOR
	//-------------------------------------------------------------------------------------------------------

	public TestMulticastReceiver()
	{
		System.out.println("Starting Client...\n");
		MulticastReceiver r = new MulticastReceiver("1", "239.0.0.1", 3000);
		Thread t = new Thread(r);
		t.start();

	}//public TestMulticastReceiver

	//-------------------------------------------------------------------------------------------------------
	
}//public class TestMulticastReceiver
