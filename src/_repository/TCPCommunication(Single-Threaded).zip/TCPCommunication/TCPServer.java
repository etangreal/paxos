package TCPCommunication;

import java.net.*;
import java.io.*;

public class TCPServer 
{
	public TCPServer()
	{
        ServerSocket serverSocket = null;

        BufferedReader in = null;
        PrintWriter out = null;
        
        String inputLine, outputLine;
        inputLine = "<no-message>\n";
        outputLine = "<no-message>\n";
        
        try 
        {
            serverSocket = new ServerSocket(4444);
        } 
        catch (IOException e) 
        {
            System.err.println("Could not listen on port: 4444.");
            System.exit(1);
        }

        Socket clientSocket = null;
        try  {
            clientSocket = serverSocket.accept();
        }
        catch (IOException e)  {
            System.err.println("Accept failed.");
            System.exit(1);
        }

        //Get socket input and output streams
		try {
	        out = new PrintWriter( clientSocket.getOutputStream(), true );
	        in =  new BufferedReader( new InputStreamReader( clientSocket.getInputStream() ));
		} 
		catch (IOException e) {
			System.out.println("KnockKnowkServer::Error on readLine::message::" + e.getMessage() );
			e.printStackTrace();
		}

        out.println(outputLine);

        try {
			while (	(inputLine = in.readLine()	) != null ) {
				outputLine = "Server received:"+inputLine;
				System.out.println(outputLine);
			     
			    out.println(outputLine);
			    if (outputLine.equals("Bye."))
			        break;
			}
		} catch (IOException e) {
			System.out.println("KnockKnowkServer::Error on readLine::message::" + e.getMessage() );
			e.printStackTrace();
		}

        try {
            out.close();
			in.close();
	        clientSocket.close();
	        serverSocket.close();
		} catch (IOException e) {
			System.out.println("KnockKnowkServer::Error on Closing Stream & Sockets::message::" + e.getMessage() );
			e.printStackTrace();
		}

	}//public TCPServer()

}//public class TCPServer
